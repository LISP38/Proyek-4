package com.example.pertemuan1.ui.theme

import androidx.compose.material3.Typography

// Gunakan Typography default Material3
val Typography = Typography()
